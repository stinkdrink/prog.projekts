import tkinter as tk
import random
from PIL import Image, ImageTk

gerbonis = {
    "Daugavpils": "atteli/daugavpils.png",
    "Jēkabpils": "atteli/jekabpils.png",
    "Jelgava": "atteli/jelgava.png",
    "Jūrmala": "atteli/jurmala.png",
    "Liepāja": "atteli/liepaja.png",
    "Ogre": "atteli/ogre.png",
    "Rēzekne": "atteli/rezekne.png",
    "Rīga": "atteli/riga.png",
    "Valmiera": "atteli/valmiera.png",
    "Ventspils": "atteli/ventspils.png"
}

def sakuma_skats():
    for widget in root.winfo_children():
        widget.destroy()

    sakuma_frame = tk.Frame(root)
    sakuma_frame.pack(fill=tk.BOTH, expand=True)

    tk.Label(sakuma_frame, text="Atpazīsti Latvijas pilsētu ģērboņus!", font=('Verdana', 24, 'bold'), fg='#800000').pack(pady=20)

    image = tk.PhotoImage(file="atteli/valstsgerbonis.png")
    attels = tk.Label(sakuma_frame, image=image)
    attels.image = image
    attels.pack(pady=10)

    tk.Button(sakuma_frame, text="Sākt", command=funkSAKT, width=20, height=2, bg='lightgrey', fg='#800000', font=('Verdana', 12, 'bold')).pack(pady=10)

def funkSAKT():
    global seciba, punkti, nepareizas_atbildes
    seciba = list(gerbonis.keys())
    random.shuffle(seciba)
    punkti = 0
    nepareizas_atbildes = []

    for widget in root.winfo_children():
        widget.destroy()

    jautajums_frame = tk.Frame(root)
    jautajums_frame.pack(fill=tk.BOTH, expand=True)

    atteli_skats = tk.Frame(jautajums_frame)
    atteli_skats.pack(pady=20)

    jautajums_skats(jautajums_frame, atteli_skats)

def jautajums_skats(jautajums_frame, atteli_skats):
    global punkti

    for widget in jautajums_frame.winfo_children():
        widget.destroy()

    if seciba:
        pilsēta = seciba.pop()
        image_path = gerbonis[pilsēta]

        img = Image.open(image_path)
        img = img.resize((200, 200))
        img = ImageTk.PhotoImage(img)

        tk.Label(jautajums_frame, text=f"Punkti: {punkti}", font=('Verdana', 14, 'bold'), fg='green').pack(pady=10)

        attels = tk.Label(jautajums_frame, image=img)
        attels.image = img
        attels.pack(pady=20)

        tk.Label(jautajums_frame, text="Kādu pilsētu attēlo šis ģērbonis?", font=('Verdana', 14)).pack(pady=10)

        atbilde_entry = tk.Entry(jautajums_frame, font=('Verdana', 14))
        atbilde_entry.pack(pady=10)

        def nosutit_atbildi():
            global punkti
            lietotaja_atbilde = atbilde_entry.get().strip().lower()
            if lietotaja_atbilde == pilsēta.lower():
                punkti += 1
            else:
                nepareizas_atbildes.append((pilsēta, lietotaja_atbilde)) 

            jautajums_skats(jautajums_frame, atteli_skats)

        tk.Button(jautajums_frame, text="Pārbaudīt atbildi", command=nosutit_atbildi, font=('Verdana', 12)).pack(pady=20)

    else:
        beigu_skats()

def beigu_skats():
    global punkti
    for widget in root.winfo_children():
        widget.destroy()

    beigu_frame = tk.Frame(root)
    beigu_frame.pack(fill=tk.BOTH, expand=True)

    tk.Label(beigu_frame, text=f"Tavi punkti: {punkti}", font=('Verdana', 24, 'bold'), fg='#800000').pack(pady=20)

    if punkti >= 8:
        uzmundrinajums = "Lieliski! Tu esi ļoti zinošs par pilsētu ģērboņiem!"
    elif punkti >= 5:
        uzmundrinajums = "Labi darīts! Tu esi ceļā uz pilsētu ģērboņa ekspertu!"
    else:
        uzmundrinajums = "Lieliski, ka mēģināji! Tavas zināšanas vēl var uzlaboties!"

    tk.Label(beigu_frame, text=uzmundrinajums, font=('Verdana', 16), fg='#800000').pack(pady=10)

    if nepareizas_atbildes:
        tk.Label(beigu_frame, text="Nepareizi atbildētie jautājumi:", font=('Verdana', 14, 'bold'), fg='red').pack(pady=10)
        for pareiza, nepareiza in nepareizas_atbildes:
            tk.Label(beigu_frame, text=f"Tava atbilde: {nepareiza} | Pareizā atbilde: {pareiza}", font=('Verdana', 12), fg='black').pack()

    tk.Button(beigu_frame, text="Sākt no jauna", command=sakuma_skats, font=('Verdana', 14)).pack(pady=20)

root = tk.Tk()
root.title("Pilsētu ģērboņa atpazīšana")
root.geometry("800x500")
root.resizable(False, False)
root.configure(bg='#EEEEEE')

sakuma_skats()
root.mainloop()
